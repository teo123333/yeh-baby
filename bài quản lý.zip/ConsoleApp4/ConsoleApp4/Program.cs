﻿using System;
using System.Collections.Generic;
using System.Xml.Linq;

namespace StudentManagement
{
    class Program
    {
        static List<Teacher> teachers = new List<Teacher>();
        static List<Student> students = new List<Student>();
        static List<Department> departments = new List<Department>();
        static List<Course> courses = new List<Course>();
        static List<Subject> subjects = new List<Subject>();
        static void Main(string[] args)
        {
            // Login
            if (Login())
            {
                Console.WriteLine("Login successful!");

                // Display menu
                ShowMenu();
            }
            else
            {
                Console.WriteLine("Login failed!");
            }

            Console.ReadLine();
        }

        static bool Login()
        {
            Console.WriteLine("Enter username:");
            string username = Console.ReadLine();

            Console.WriteLine("Enter password:");
            string password = Console.ReadLine();

            // Check login information
            // In this example, only simple password checking is performed
            if (username == "admin" && password == "admin")
            {
                return true;
            }

            return false;
        }

        static void ShowMenu()
        {
            while (true)
            {
                Console.WriteLine("----- Student Management -----");
                Console.WriteLine("1. Add student");
                Console.WriteLine("2. Add teacher");
                Console.WriteLine("3. Add department");
                Console.WriteLine("4. Add course");
                Console.WriteLine("5. Add subject");
                Console.WriteLine("6. Show student list");
                Console.WriteLine("7. Show teacher list");
                Console.WriteLine("8. Exit");
                Console.WriteLine("-----------------------------");
                Console.WriteLine("Enter your choice:");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddStudent();
                        break;
                    case "2":
                        AddTeacher();
                        break;
                    case "3":
                        AddDepartment();
                        break;
                    case "4":
                        AddCourse();
                        break;
                    case "5":
                        AddSubject();
                        break;
                    case "6":
                        ShowStudents();
                        break;
                    case "7":
                        ShowTeachers();
                        break;
                    case "8":
                        return;
                    default:
                        Console.WriteLine("Invalid choice!");
                        break;
                }
            }
        }


            static void AddStudent()
            {
                Console.WriteLine("----- Add student -----");
                Console.WriteLine("Enter student name:");
                string name = Console.ReadLine();

                Console.WriteLine("Enter department:");
                string department = Console.ReadLine();

                Console.WriteLine("Enter course:");
                string course = Console.ReadLine();

                Console.WriteLine("Enter username:");
                string username = Console.ReadLine();

                Console.WriteLine("Enter password:");
                string password = Console.ReadLine();

                Account account = new Account(username, password);
                Student student = new Student(name, department, course, account);
                students.Add(student);

                Console.WriteLine("Student added successfully!");
            }
        

        static void AddTeacher()
        {
            Console.WriteLine("----- Add teacher -----");
            Console.WriteLine("Enter teacher name:");
            string name = Console.ReadLine();

            Console.WriteLine("Enter department:");
            string department = Console.ReadLine();

            Console.WriteLine("Enter username:");
            string username = Console.ReadLine();

            Console.WriteLine("Enter password:");
            string password = Console.ReadLine();

            Account account = new Account(username, password);
            Teacher teacher = new Teacher(name, department, account);
            teachers.Add(teacher);

            Console.WriteLine("Teacher added successfully!");
        }

        static void AddDepartment()
        {
            Console.WriteLine("----- Add department -----");
            Console.WriteLine("Enter department name:");
            string name = Console.ReadLine();

            Department department = new Department(name);
            departments.Add(department);

            Console.WriteLine("Department added successfully!");
        }

        static void AddCourse()
        {
            Console.WriteLine("----- Add course -----");
            Console.WriteLine("Enter course name:");
            string name = Console.ReadLine();

            Course course = new Course(name);
            courses.Add(course);

            Console.WriteLine("Course added successfully!");
        }

        static void AddSubject()
        {
            Console.WriteLine("----- Add subject -----");
            Console.WriteLine("Enter subject name:");
            string name = Console.ReadLine();

            Console.WriteLine("Enter teacher for the subject:");
            string teacherName = Console.ReadLine();

            Teacher teacher = teachers.Find(t => t.Name == teacherName);

            if (teacher != null)
            {
                Subject subject = new Subject(name, teacher);
                subjects.Add(subject);

                Console.WriteLine("Subject added successfully!");
            }
            else
            {
                Console.WriteLine("Teacher not found!");
            }
        }

        static void ShowStudents()
        {
            Console.WriteLine("----- Student List -----");

            foreach (var student in students)
            {
                Console.WriteLine($"Student name: {student.Name}");
                Console.WriteLine($"Department: {student.Department}");
                Console.WriteLine($"Course: {student.Course}");
                Console.WriteLine($"Account: Username - {student.Account.Username}, Password - {student.Account.Password}");
                Console.WriteLine("-----------------------------");
            }
        }

        static void ShowTeachers()
        {
            Console.WriteLine("----- Teacher List -----");

            foreach (var teacher in teachers)
            {
                Console.WriteLine($"Teacher name: {teacher.Name}");
                Console.WriteLine($"Department: {teacher.Department}");
                Console.WriteLine($"Account: Username - {teacher.Account.Username}, Password - {teacher.Account.Password}");
                Console.WriteLine("-----------------------------");
            }
        }
    }

    class Person
    {
        public string Name { get; set; }
    }

    class Teacher : Person
    {
        public string Department { get; set; }
        public Account Account { get; set; } // Thêm thuộc tính Account

        public Teacher(string name, string department, Account account)
        {
            Name = name;
            Department = department;
            Account = account;
        }
    }

    class Student : Person
    {
        public string Department { get; set; }
        public string Course { get; set; }
        public Account Account { get; set; } // Thêm thuộc tính Account

        public Student(string name, string department, string course, Account account)
        {
            Name = name;
            Department = department;
            Course = course;
            Account = account;
        }
    }

    class Account
    {
        public string Username { get; set; }
        public string Password { get; set; }

        public Account(string username, string password)
        {
            Username = username;
            Password = password;
        }
    }

    class Department
    {
        public string Name { get; set; }

        public Department(string name)
        {
            Name = name;
        }
    }

    class Course
    {
        public string Name { get; set; }

        public Course(string name)
        {
            Name = name;
        }
    }

    class Subject
    {
        public string Name { get; set; }
        public Teacher Teacher { get; set; }

        public Subject(string name, Teacher teacher)
        {
            Name = name;
            Teacher = teacher;
        }
    }
}