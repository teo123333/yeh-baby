/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inttreenode;

/**
 *
 * @author PC
 */
public class BSTnodetree {
    class Node {
    int value;
    Node left, right;

    public Node(int value) {
        this.value = value;
        left = right = null;
    }
}

class BST {
    Node root;

    public BST() {
        root = null;
    }

    public void insert(int value) {
        root = insertRec(root, value);
    }

    private Node insertRec(Node root, int value) {
        if (root == null) {
            root = new Node(value);
            return root;
        }
        if (value < root.value)
            root.left = insertRec(root.left, value);
        else if (value > root.value)
            root.right = insertRec(root.right, value);

        return root;
    }

    public void inOrder() {
        inOrderRec(root);
    }

    private void inOrderRec(Node root) {
        if (root != null) {
            inOrderRec(root.left);
            System.out.print(root.value + " ");
            inOrderRec(root.right);
        }
    }

    public boolean search(int value) {
        return searchRec(root, value);
    }

    private boolean searchRec(Node root, int value) {
        if (root == null)
            return false;
        if (root.value == value)
            return true;
        return value < root.value ? searchRec(root.left, value) : searchRec(root.right, value);
    }

    // Phương thức tìm điểm chung gần nhất (LCA)
    private Node findLCA(Node node, int n1, int n2) {
        if (node == null) {
            return null;
        }
        if (node.value > n1 && node.value > n2) {
            return findLCA(node.left, n1, n2);
        }
        if (node.value < n1 && node.value < n2) {
            return findLCA(node.right, n1, n2);
        }
        return node;
    }

    // Phương thức tính khoảng cách từ gốc đến một giá trị
    private int findDistanceFromRoot(Node node, int value) {
        if (node.value == value) {
            return 0;
        } else if (node.value > value) {
            return 1 + findDistanceFromRoot(node.left, value);
        } else {
            return 1 + findDistanceFromRoot(node.right, value);
        }
    }

    // Phương thức tính khoảng cách giữa hai giá trị
    public int findDistanceBetweenNodes(int n1, int n2) {
        Node lca = findLCA(root, n1, n2);
        int d1 = findDistanceFromRoot(lca, n1);
        int d2 = findDistanceFromRoot(lca, n2);
        return d1 + d2;
    }
}

}
