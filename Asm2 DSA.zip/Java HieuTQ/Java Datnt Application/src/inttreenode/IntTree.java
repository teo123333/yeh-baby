/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inttreenode;

import java.util.Scanner;

/**
 *
 * @author Nghia deep try
 */
public class IntTree {
    
public void printPreoder() {
        printPreoder(root);
        System.out.println(); // end the line of output
        }
        private void printPreoder(IntTreeNode root) {
        // (base case is implicitly to do nothing on null)
        if (root != null) {
        // recursive case: print center, left, right
        System.out.print(root.data + " ");
        printPreoder(root.left);
        printPreoder(root.right);
        }
    }   
   
    IntTreeNode root; //null for an empty tree
    public static void main(String[] args) {
        
        IntTree tree = new IntTree();
        Scanner sc = new Scanner(System.in);
        
        
        System.out.println("First number (root node) : ");
        IntTreeNode first = new IntTreeNode(sc.nextInt());
        tree.root = first;
        
       
        
       /// Second
          System.out.println("Second number (root left) : ");
        IntTreeNode second = new IntTreeNode(sc.nextInt());
        tree.root.left = second;
        
        ///Third
          System.out.println("Third number (root right) : ");
        IntTreeNode third = new IntTreeNode(sc.nextInt());
        tree.root.right = third;
        
        ///Fourth 
          System.out.println("Fourth number (root left left) : ");
        IntTreeNode fourth = new IntTreeNode(sc.nextInt());
        tree.root.left.left = fourth;
        
        
        System.out.println("Print the tree in pree-oder: ");
        tree.printPreoder();
    }
    
}