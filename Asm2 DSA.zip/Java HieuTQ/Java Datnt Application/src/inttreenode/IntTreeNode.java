/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inttreenode;

/**
 *
 * @author Nghia deep try
 */
public class IntTreeNode {
    public int data; // Data stored at this node
public IntTreeNode left; // Reference to the left subtree
public IntTreeNode right; // Reference to the right subtree
// Constructs a leaf node with the given data.


// Constructs a branch node with the given data and links.
public IntTreeNode(int data) {
this.data = data;
this.left = left;
this.right = right;
}
}