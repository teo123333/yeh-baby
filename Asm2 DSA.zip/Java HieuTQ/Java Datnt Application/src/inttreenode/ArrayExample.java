import java.util.Arrays;

public class ArrayExample {

    public static void main(String[] args) {
        // Khởi tạo một mảng các số nguyên
        int[] numbers = {5, 2, 8, 10, 3};

        // In ra mảng ban đầu
        System.out.println("Initial array: " + Arrays.toString(numbers));

        // Tính tổng các phần tử trong mảng
        int sum = 0;
        for (int num : numbers) {
            sum += num;
        }
        // In ra tổng của các số trong mảng
        System.out.println("Sum of numbers in array: " + sum);

        // Sắp xếp mảng theo thứ tự tăng dần
        Arrays.sort(numbers);
        System.out.println("Array after sorting: " + Arrays.toString(numbers));
    }
}
