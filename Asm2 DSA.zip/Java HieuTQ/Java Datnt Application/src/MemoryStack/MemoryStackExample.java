/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MemoryStack;

/**
 *
 * @author PC
 */
public class MemoryStackExample {
    public static void main(String[] args) {
        int mainVar = 5;
        System.out.println("Main starts");
        functionA(mainVar);
        System.out.println("Main ends");
    }

    public static void functionA(int a) {
        int funcAVar = a + 10;
        System.out.println("In functionA");
        functionB(funcAVar);
    }

    public static void functionB(int b) {
        int funcBVar = b * 2;
        System.out.println("In functionB");
    }
}
