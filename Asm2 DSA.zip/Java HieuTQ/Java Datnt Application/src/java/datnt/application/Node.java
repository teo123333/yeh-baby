/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java.datnt.application;

/**
 *
 * @author PC
 */
public class Node {
      public int data ;
Node next;
public Node(int data){
    this.data = data;
    this.next = null;
}
    
}
