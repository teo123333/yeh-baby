public class Job {
    private String jobName;

    public Job(String jobName) {
        this.jobName = jobName;
    }

    public String getJobName() {
        return jobName;
    }

    @Override
    public String toString() {
        return jobName;
    }
}
