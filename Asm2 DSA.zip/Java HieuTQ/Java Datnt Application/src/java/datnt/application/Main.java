

import java.util.Scanner;

public class Main {

  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    // Declare an array of integers
    int[] numbers = {5, 10, 20, 15, 25};

    // Display the original array
    System.out.println("Original array:");
    for (int num : numbers) {
      System.out.print(num + " ");
    }
    System.out.println();

    // Get user input for element position
    System.out.println("Enter the index of the element to modify (0-4): ");
    int index = scanner.nextInt();

    // Get user input for new value
    System.out.println("Enter the new value for the element: ");
    int newValue = scanner.nextInt();

    // Check for valid index
    if (index >= 0 && index < numbers.length) {
      numbers[index] = newValue;  // Modify the element at the specified index

      // Display the modified array
      System.out.println("Modified array:");
      for (int num : numbers) {
        System.out.print(num + " ");
      }
      System.out.println();
    } else {
      System.out.println("Invalid index. Please enter a value between 0 and 4.");
    }
  }
}
