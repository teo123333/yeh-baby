public class StudentLinkedList {
    private ListNode head; // Đỉnh của danh sách liên kết

    // Lớp nút (Node) trong danh sách liên kết
    private static class ListNode {
        private Student data;
        private ListNode next;

        public ListNode(Student data) {
            this.data = data;
            this.next = null;
        }
    }

    // Phương thức thêm sinh viên vào đầu danh sách
    public void addToFront(Student student) {
        ListNode newNode = new ListNode(student);
        newNode.next = head;
        head = newNode;
    }

    // Phương thức hiển thị danh sách sinh viên
    public void displayList() {
        ListNode current = head;
        while (current != null) {
            System.out.println(current.data);
            current = current.next;
        }
    }

    public static void main(String[] args) {
        StudentLinkedList list = new StudentLinkedList();

        // Thêm sinh viên vào danh sách
        list.addToFront(new Student(1, "Alice", 85.5));
        list.addToFront(new Student(2, "Bob", 76.0));
        list.addToFront(new Student(3, "Carol", 92.3));

        // Hiển thị danh sách sinh viên
        System.out.println("Student list:");
        list.displayList();
    }
}
