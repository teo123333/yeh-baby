import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Manager {
    private List<Student> students;

    public Manager() {
        this.students = new ArrayList<>();
    }

    public void addStudent(int studentId, String name, double marks) {
        Student student = new Student(studentId, name, marks);
        students.add(student);
    }

    public boolean editStudent(int studentId, String name, Double marks) {
        Optional<Student> optionalStudent = students.stream().filter(s -> s.getStudentId() == studentId).findFirst();
        if (optionalStudent.isPresent()) {
            Student student = optionalStudent.get();
            if (name != null) {
                student.setName(name);
            }
            if (marks != null) {
                student.setMarks(marks);
            }
            return true;
        }
        return false;
    }

    public void deleteStudent(int studentId) {
        students.removeIf(s -> s.getStudentId() == studentId);
    }

   public void insertionSort() {
    int n = students.size();
    for (int i = 1; i < n; ++i) {
        Student key = students.get(i);
        int j = i - 1;

        // Di chuyển các phần tử của mảng đã sắp xếp về sau nếu phần tử lớn hơn key
        while (j >= 0 && students.get(j).getMarks() < key.getMarks()) {
            students.set(j + 1, students.get(j));
            j = j - 1;
        }
        students.set(j + 1, key);
    }
}

    public void sortStudents() {
    insertionSort();
}
    public Student searchStudent(int studentId) {
        for (Student student : students) {
            if (student.getStudentId() == studentId) {
                return student;
            }
        }
        return null;
    }

    public void displayStudents() {
        for (Student student : students) {
            System.out.println(student);
        }
    }

    public static void main(String[] args) {
        Manager manager = new Manager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Choose an option: ");
            System.out.println("1. Add Student");
            System.out.println("2. Edit Student");
            System.out.println("3. Delete Student");
            System.out.println("4. Sort Students");
            System.out.println("5. Search Student");
            System.out.println("6. Display Students");
            System.out.println("7. Exit");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Enter Student ID:");
                    int id = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    System.out.println("Enter Student Name:");
                    String name = scanner.nextLine();
                    System.out.println("Enter Student Marks:");
                    double marks = scanner.nextDouble();
                    manager.addStudent(id, name, marks);
                    break;
                case 2:
                    System.out.println("Enter Student ID to Edit:");
                    int editId = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    System.out.println("Enter New Student Name (or leave blank):");
                    String newName = scanner.nextLine();
                    System.out.println("Enter New Student Marks (or leave blank):");
                    String marksInput = scanner.nextLine();
                    Double newMarks = marksInput.isEmpty() ? null : Double.parseDouble(marksInput);
                    boolean updated = manager.editStudent(editId, newName.isEmpty() ? null : newName, newMarks);
                    if (updated) {
                        System.out.println("Student updated successfully.");
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;
                case 3:
                    System.out.println("Enter Student ID to Delete:");
                    int deleteId = scanner.nextInt();
                    manager.deleteStudent(deleteId);
                    break;
                case 4:
                    manager.sortStudents();
                    break;
                case 5:
                    System.out.println("Enter Student ID to Search:");
                    int searchId = scanner.nextInt();
                    Student student = manager.searchStudent(searchId);
                    if (student != null) {
                        System.out.println("Student found: " + student);
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;
                case 6:
                    manager.displayStudents();
                    break;
                case 7:
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
