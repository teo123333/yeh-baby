package com.mycompany.insertionsort;
public class InsertionSort {
    public void sort(int[] arr) {
        int n = arr.length;
        // Iterate over each element starting from the second one
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;
            // Move elements of arr[0..i-1] that are less than key
            // to one position ahead of their current position
            while (j >= 0 && arr[j] < key) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
    }
       public void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
    public static void main(String[] args) {
        InsertionSort insertionSort = new InsertionSort();
        int[] arr = {29, 12, 45, 7, 33};
        System.out.println("Array before sorting:");
        insertionSort.printArray(arr);
        insertionSort.sort(arr);
        System.out.println("Sorted array:");
        insertionSort.printArray(arr);
    }
}